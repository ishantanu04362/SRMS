/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.0.41-community-nt : Database - sis
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sis` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sis`;

/*Table structure for table `faculty_reg` */

DROP TABLE IF EXISTS `faculty_reg`;

CREATE TABLE `faculty_reg` (
  `id` varchar(20) NOT NULL,
  `name` varchar(400) default NULL,
  `email` varchar(400) default NULL,
  `dob` varchar(400) default NULL,
  `mobile` varchar(400) default NULL,
  `gender` varchar(400) default NULL,
  `postal_address` varchar(400) default NULL,
  `password` varchar(400) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `faculty_reg` */

insert  into `faculty_reg`(`id`,`name`,`email`,`dob`,`mobile`,`gender`,`postal_address`,`password`) values ('121','Mrs Anita Sharma','anita273@gmail.com','1996-5-25','978647833','female','302029','anita'),('121212','','','1995-1-1','','male','',''),('22','','','1995-1-1','','22','',''),('222',NULL,NULL,NULL,NULL,NULL,NULL,'password'),('23','','','1995-1-1','','23','','donk'),('89','Mr Shantanu Sharma','shantanu04362@gmail.com','1995-1-1','9878998789','male','302002','password4362');

/*Table structure for table `notice_info` */

DROP TABLE IF EXISTS `notice_info`;

CREATE TABLE `notice_info` (
  `id` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `subject` varchar(20) NOT NULL,
  `notice` varchar(1000) NOT NULL,
  `by` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `notice_info` */

insert  into `notice_info`(`id`,`date`,`subject`,`notice`,`by`) values ('2','1995-01-01','','','1995-01-01');

/*Table structure for table `reportcard` */

DROP TABLE IF EXISTS `reportcard`;

CREATE TABLE `reportcard` (
  `enroll` varchar(20) NOT NULL,
  `physics` int(20) NOT NULL,
  `chemistry` int(20) NOT NULL,
  `maths` int(20) NOT NULL,
  `english` int(20) NOT NULL,
  `biology` int(20) NOT NULL,
  `percent` int(20) NOT NULL,
  PRIMARY KEY  (`enroll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `reportcard` */

insert  into `reportcard`(`enroll`,`physics`,`chemistry`,`maths`,`english`,`biology`,`percent`) values ('!%EDE',22,89,97,67,43,63),('12',87,77,67,97,87,83),('15EJCITPOE073',99,83,97,92,86,91),('21',45,33,22,22,45,33),('45',87,87,87,87,87,87);

/*Table structure for table `student_reg` */

DROP TABLE IF EXISTS `student_reg`;

CREATE TABLE `student_reg` (
  `enroll` varchar(30) NOT NULL,
  `id` varchar(30) default NULL,
  `roll_no` varchar(30) default NULL,
  `name` varchar(50) default NULL,
  `mobile` varchar(20) default NULL,
  `email` varchar(100) default NULL,
  `college` varchar(100) default NULL,
  `semester` varchar(10) default NULL,
  `year_of_admission` date default NULL,
  `postal_address` varchar(20) default NULL,
  `dob` date default NULL,
  `gender` varchar(20) default NULL,
  `password` varchar(100) default NULL,
  PRIMARY KEY  (`enroll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student_reg` */

insert  into `student_reg`(`enroll`,`id`,`roll_no`,`name`,`mobile`,`email`,`college`,`semester`,`year_of_admission`,`postal_address`,`dob`,`gender`,`password`) values ('','','','','','','','1st','1995-01-01','','1995-01-01','1st',''),('!%EDE','121','108','Shantanu','9529140258','Shantanusharma.it19@jecrc.ac.in','JECRC','6th','1993-03-08','302002','1999-01-01','male','success'),('12','','','Shantanu sharma','9529140258','','JECRC','1st','1995-01-01','','1995-01-01','male','123'),('15EJCITPOE073','71','15EJCIT073','Shantanu sharma','9529140258','shantanu04362@gmail.com','JECRC','5th','1990-07-25','302002','1999-10-27','male','password4362'),('21','22','87','shantanu','98989','nsajsj','JECRC','1st','1995-01-01','','1995-01-01','male','password'),('2121','','','','','','','1st','1995-01-01','','1995-01-01','male',''),('45','','','','','','','1st','1995-01-01','','1995-01-01','male','');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
