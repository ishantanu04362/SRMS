import java.sql.*;
public class connector {

	public static Connection con=null;
	static{
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/sis","root", "rat");
			
		}
		catch (Exception e){
		}
		
	}
}
