import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JSeparator;
import javax.swing.JButton;

public class View_Result extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Result frame = new View_Result();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View_Result() {
		setTitle("RESULT");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 462, 611);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
		System.out.println("RESULT CALLED!!!");
		JLabel lblEnroll = new JLabel("ENROLL");
		lblEnroll.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel = new JLabel("NAME");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_1 = new JLabel("MOBILE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_2 = new JLabel("COLLEGE");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JSeparator separator = new JSeparator();
		
		JLabel lblNewLabel_7 = new JLabel("PHYSICS");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_8 = new JLabel("CHEMISTRY");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_9 = new JLabel("MATHS");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_10 = new JLabel("ENGLISH");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_11 = new JLabel("BIOLOGY");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JSeparator separator_1 = new JSeparator();
		
		JLabel lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_15 = new JLabel("");
		lblNewLabel_15.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_16 = new JLabel("");
		lblNewLabel_16.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_17 = new JLabel("RESULT");
		lblNewLabel_17.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_18 = new JLabel("PERCENTAGE");
		lblNewLabel_18.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_19 = new JLabel("DIVISION");
		lblNewLabel_19.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_20 = new JLabel("");
		lblNewLabel_20.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_21 = new JLabel("");
		lblNewLabel_21.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_22 = new JLabel("");
		lblNewLabel_22.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JButton btnNewButton = new JButton("BACK TO MAIN MENU");
		
		JButton btnNewButton_1 = new JButton("VIEW ANOTHER RESULT");

		ShareDataEnroll data=new ShareDataEnroll();String enroll=data.getData();
		
		connector con=new connector();
		try{
			PreparedStatement ps=connector.con.prepareStatement("select * from reportcard");
			ResultSet rs=ps.executeQuery();
			
			PreparedStatement ps1=connector.con.prepareStatement("select * from student_reg");
			ResultSet rs1=ps1.executeQuery();
			
		
			while(rs1.next())
			{
				String enrollchk=rs1.getString("enroll");
				System.out.println(enrollchk);
				String name=rs1.getString("name");
				String mobile=rs1.getString("mobile");
				String college=rs1.getString("college");
				if(enrollchk.equals(enroll))
				{
					lblNewLabel_3.setText(enrollchk);
					lblNewLabel_4.setText(name);
					lblNewLabel_5.setText(mobile);
					lblNewLabel_6.setText(college);
					
				}
			}
			while(rs.next())
			{
				String enrollchk=rs.getString("enroll");
				System.out.println(enrollchk);
				String physics=String.valueOf(rs.getString("physics"));
				
				String chemistry=String.valueOf(rs.getString("chemistry"));
				String maths=String.valueOf(rs.getString("maths"));
				String english=String.valueOf(rs.getString("english"));
				String biology=String.valueOf(rs.getString("biology"));
				int percent=rs.getInt("percent");
								
				
				
				String percent1=String.valueOf(percent);
				if(enrollchk.equals(enroll))
				{
					lblNewLabel_12.setText(physics);
					lblNewLabel_13.setText(chemistry);
					lblNewLabel_14.setText(maths);
					lblNewLabel_15.setText(english);
					lblNewLabel_16.setText(biology);
				
					if(percent<=30)
					{
						lblNewLabel_20.setText("FAIL");
						lblNewLabel_22.setText("FAIL");
						lblNewLabel_21.setText(percent1);
					}
					else if((percent>30) && (percent<=45))
					{

						lblNewLabel_20.setText("PASS");
						lblNewLabel_22.setText("THIRD");
						lblNewLabel_21.setText(percent1);
					}
					else if((percent>45) && (percent<60))
					{

						lblNewLabel_20.setText("PASS");
						lblNewLabel_22.setText("SECOND");
						lblNewLabel_21.setText(percent1);
					}
					else if((percent>=60) && (percent<90))
					{

						lblNewLabel_20.setText("PASS");
						lblNewLabel_22.setText("FIRST");
						lblNewLabel_21.setText(percent1);
					}
					else if(percent>=90)
					{

						lblNewLabel_20.setText("PASS");
						lblNewLabel_22.setText("MERIT");
						lblNewLabel_21.setText(percent1);
					}
				}
			}
		}
		catch(Exception e)
		{}
		
		
		//BACK TO MAIN MENU BUTTON
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Start1 obj=new Start1();
				obj.setVisible(true);
				View_Result.this.setVisible(false);
			}
				});
		
		
		//VIEW ANOTHER RESULT
		btnNewButton_1.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Student_Login_Window obj1=new Student_Login_Window();
				obj1.setVisible(true);
				View_Result.this.setVisible(false);
			}
				});
		
		
		
		
		
		
		
		
		
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(36)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblEnroll)
							.addGap(99)
							.addComponent(lblNewLabel_3))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel)
								.addComponent(lblNewLabel_1)
								.addComponent(lblNewLabel_2))
							.addGap(77)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_6)
								.addComponent(lblNewLabel_5)
								.addComponent(lblNewLabel_4))))
					.addContainerGap(257, Short.MAX_VALUE))
				.addComponent(separator_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(separator, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(88)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_19)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_7)
								.addComponent(lblNewLabel_8)
								.addComponent(lblNewLabel_9)
								.addComponent(lblNewLabel_10)
								.addComponent(lblNewLabel_18)
								.addComponent(lblNewLabel_17)
								.addComponent(lblNewLabel_11))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(72)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_16)
										.addComponent(lblNewLabel_15)
										.addComponent(lblNewLabel_14)
										.addComponent(lblNewLabel_13)
										.addComponent(lblNewLabel_12)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(61)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_21)
										.addComponent(lblNewLabel_20)
										.addComponent(lblNewLabel_22))))))
					.addContainerGap(157, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(34)
					.addComponent(btnNewButton)
					.addGap(83)
					.addComponent(btnNewButton_1)
					.addContainerGap(95, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEnroll)
						.addComponent(lblNewLabel_3))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_4))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(lblNewLabel_5))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(lblNewLabel_6))
					.addGap(36)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_7)
						.addComponent(lblNewLabel_12))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_8)
						.addComponent(lblNewLabel_13))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_9)
						.addComponent(lblNewLabel_14))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_10)
						.addComponent(lblNewLabel_15))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_16)
						.addComponent(lblNewLabel_11))
					.addGap(25)
					.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
					.addGap(14)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_17)
						.addComponent(lblNewLabel_20))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_18)
						.addComponent(lblNewLabel_21))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_19)
						.addComponent(lblNewLabel_22))
					.addPreferredGap(ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
