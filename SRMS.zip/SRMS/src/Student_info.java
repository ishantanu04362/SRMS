import java.awt.ActiveEvent;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javafx.event.ActionEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

public class Student_info extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_info frame = new Student_info();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_info() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 688);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("ENROLL");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_2 = new JLabel("ROLL NUMBER");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_3 = new JLabel("NAME");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_4 = new JLabel("MOBILE");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_5 = new JLabel("EMAIL");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_6 = new JLabel("COLLEGE");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_7 = new JLabel("SEMESTER");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_8 = new JLabel("YEAR OF ADMISSION");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_9 = new JLabel("POSTAL ADDRESS");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_10 = new JLabel("DATE OF BIRTH");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_11 = new JLabel("GENDER");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblNewLabel_12 = new JLabel("PASSWORD");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);

		
		textField_2 = new JTextField();
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		
		String[] semester={"1st","2nd","3rd","4th","5th","6th","7th","8th"};
		JComboBox comboBox = new JComboBox(semester);
		
		String[] day={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
		String[] year={"1995","1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2012","2013","2014","2015","2016","2017","2018"};
		String[] month={"1","2","3","4","5","6","7","8","9","10","11","12"};
		
		String[] gender={"male","female"};
		JComboBox comboBox_1 = new JComboBox(day);
		
		JComboBox comboBox_2 = new JComboBox(month);
		
		JComboBox comboBox_3 = new JComboBox(year);
		
		JComboBox comboBox_4 = new JComboBox(day);
		
		JComboBox comboBox_5 = new JComboBox(month);
		
		JComboBox comboBox_6 = new JComboBox(year);
		
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		
		JComboBox comboBox_7 = new JComboBox(gender);
		
		
		passwordField = new JPasswordField();
		
		
		
		//SAVE BUTTON
		JButton btnNewButton = new JButton("SAVE");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
	


		btnNewButton.addActionListener(new ActionListener(){
				
				@Override
				public void actionPerformed(java.awt.event.ActionEvent ae) {

					String dd2=(String) comboBox_4.getSelectedItem();
					String mm2=(String) comboBox_5.getSelectedItem();
					String yy2=(String) comboBox_6.getSelectedItem();


					String dd1=(String) comboBox_1.getSelectedItem();
					String mm1=(String) comboBox_2.getSelectedItem();
					String yy1=(String) comboBox_3.getSelectedItem();
					String enroll=textField.getText();
					String id=(String)textField_1.getText();
					String roll=(String)textField_2.getText();
					String name=(String)textField_3.getText();
					String mobile=textField_4.getText();
					String email=textField_5.getText();
					String college=textField_6.getText();
					String semester11=(String)comboBox.getSelectedItem();
					String yoa=yy1+"-"+mm1+"-"+dd1;
					String dob=yy2+"-"+mm2+"-"+dd2;
					String PostalAddress=textField_7.getText();
					String g1=(String)comboBox_7.getSelectedItem();
					String password=String.valueOf(passwordField.getPassword());
					
					
					Connection con=null;
					try{
						Class.forName("com.mysql.jdbc.Driver");
						con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sis","root","rat");
					}
					catch(Exception e){
						
					}
					int i=0;
					try{
						PreparedStatement ps=con.prepareStatement("insert into student_reg values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
						ps.setString(1,enroll);
						ps.setString(2,id);
						ps.setString(3,roll);
						ps.setString(4,name);
						ps.setString(5,mobile);
						ps.setString(6,email);
						ps.setString(7,college);
						ps.setString(8,semester11);
						ps.setString(9,yoa);
						ps.setString(10,PostalAddress);
						ps.setString(11,dob);
						ps.setString(12,g1);
						ps.setString(13,password);
						i=ps.executeUpdate();
					}
					catch(Exception e)
					{}
					if(i==0)
						System.out.println("Values Not Inserted");
					else
						System.out.println("Values Inserted!!!");
								
				}
			});	
			
			
	
		//RESET BUTTON
		JButton btnNewButton_1 = new JButton("RESET");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		btnNewButton_1.addActionListener(new ActionListener()
				
				{
		public void actionPerformed(java.awt.event.ActionEvent e)
		{
			textField.setText(null);
			textField_1.setText(null);
			textField_2.setText(null);
			textField_3.setText(null);
			textField_4.setText(null);
			textField_5.setText(null);
			textField_6.setText(null);
			textField_7.setText(null);
			passwordField.setText(null);
			comboBox.setSelectedItem(semester[0]);
			comboBox_1.setSelectedItem(day[0]);
			comboBox_2.setSelectedItem(month[0]);
			comboBox_3.setSelectedItem(year[0]);
			comboBox_4.setSelectedItem(day[0]);
			comboBox_5.setSelectedItem(month[0]);
			comboBox_6.setSelectedItem(year[0]);
			comboBox_7.setSelectedItem(gender[0]);
			
			
		}
			
				}
				
				);
		
		
		//LOGIN BUTTON
		JButton btnNewButton_2 = new JButton("LOGIN");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_2.addActionListener(new ActionListener()
				{
			public void actionPerformed(java.awt.event.ActionEvent ae)
			{
				Student_Login_Window obj=new Student_Login_Window();
				obj.setVisible(true);
				Student_info.this.setVisible(false);
			}
				});
		
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(37)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_1)
						.addComponent(lblNewLabel_2)
						.addComponent(lblNewLabel_3)
						.addComponent(lblNewLabel_4)
						.addComponent(lblNewLabel_5)
						.addComponent(lblNewLabel_6)
						.addComponent(lblNewLabel_7)
						.addComponent(lblNewLabel_8)
						.addComponent(lblNewLabel_9)
						.addComponent(lblNewLabel_10)
						.addComponent(lblNewLabel_11)
						.addComponent(lblNewLabel_12))
					.addGap(45)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(passwordField, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(comboBox_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(comboBox_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(comboBox_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(comboBox_6, 0, 56, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(comboBox_3, GroupLayout.PREFERRED_SIZE, 56, GroupLayout.PREFERRED_SIZE))
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_7, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField_6, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField_5, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField_4, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField_3, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField_2, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
						.addComponent(textField, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE))
					.addGap(73))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnNewButton_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnNewButton_2)
					.addPreferredGap(ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
					.addComponent(btnNewButton)
					.addGap(95))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(36)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_1)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_2)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_3)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_4)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_5)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_6)
						.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_7)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_8)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(comboBox_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel_9)
							.addGap(18)
							.addComponent(lblNewLabel_10))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(comboBox_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(comboBox_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(comboBox_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_11)
						.addComponent(comboBox_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_12)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(50)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton_2))
					.addContainerGap(54, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	

	
	}	
	}











		