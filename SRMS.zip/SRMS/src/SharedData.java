
public class SharedData {
	static String enr=null;
public void setData(String enroll)
{
	
	SharedData.enr=enroll;
	}
public String getData()
{
	return enr;
	}
}
